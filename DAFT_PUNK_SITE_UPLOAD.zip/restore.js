(()=>{
// Resolve every original root-relative Daft Punk link within a Pages project path.
const current=document.currentScript;
const root=new URL('./',current?.src||location.href);
const oldHost=/^(?:www\.)?daftpunk\.(?:com|net)$/i;
const open=window.open.bind(window);
function resolved(url){
 const u=new URL(url,location.href);
 if(u.origin!==location.origin&&!oldHost.test(u.hostname))return null;
 if(u.pathname.includes('tour.cgi'))return new URL('tour.html'+u.search+u.hash,root).href;
 if(u.origin===location.origin&&u.pathname.startsWith(root.pathname))return u.href;
 return new URL(u.pathname.replace(/^\/+/, '')+u.search+u.hash,root).href;
}
window.open=function(url,target,features){
 if(!url)return window;
 const dest=resolved(url);
 if(!dest)return open(url,target,features);
 let frame;
 try{frame=parent.frames['content']}catch(e){}
 if(frame){frame.location.href=dest;return frame;}
 location.href=dest;return window;
};
document.addEventListener('DOMContentLoaded',()=>{
 for(const link of document.querySelectorAll('a,area')){
   const value=link.getAttribute('href')||'';
   if(value.includes('tour.cgi'))link.setAttribute('href',new URL('tour.html',root).href);
   else if(/^https?:\/\/(?:www\.)?daftpunk\.(?:com|net)\//i.test(value)){
     const updated=resolved(value);
     if(updated)link.setAttribute('href',updated);
   }
 }
});
})();
